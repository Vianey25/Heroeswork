CREATE TABLE registro_visitadores(
    numero_empleado VARCHAR(10) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    primer_apellido VARCHAR(50) NOT NULL,
    segundo_apellido VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    password  VARCHAR(32) NOT NULL,
    cargo VARCHAR(20) check(cargo='JEFE' OR cargo='VISITADOR')
);



CREATE TABLE registro_usuarios(
    id_usuario INTEGER PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    primer_apellido VARCHAR(50) NOT NULL,
    segundo_apellido VARCHAR(50) NOT NULL,
    edad INT(3) NOT NULL,
    telefono VARCHAR(10) NOT NULL,
    genero VARCHAR(30) check (genero='MASCULINO' OR genero='FEMENINO' OR genero='OTRO'),
    email VARCHAR(50) NOT NULL,
    password VARCHAR(32) NOT NULL 
);



CREATE TABLE captura_tramites(
    id_tramite INTEGER PRIMARY KEY AUTO_INCREMENT,
    folio_tramite VARCHAR(10),
    hora_de_captura TIME,
    fecha_de_captura DATE,
    lugar_atencion VARCHAR(50),
    nombre VARCHAR(50),
    primer_apellido VARCHAR(50),
    segundo_apellido VARCHAR(50),
    curp VARCHAR(18),
    edad INT(10),
    genero VARCHAR(10) check (genero='Masculino' OR genero='Femenino' OR genero='Otro'),
    identificacion VARCHAR(50) check (identificacion= 'Ine' OR identificacion='Pasaport' OR identificacion='Licencia de manejo'  
    OR identificacion='Credencial del INSEN' OR identificacion='Cartilla militar' OR identificacion='Constancia de avecindado con foto' OR identificacion='Credencial (RAN)'),
    folio_de_identificacion VARCHAR(50),
    telefono VARCHAR(10),
    direccion VARCHAR(50),
    municipio VARCHAR(50),
    estado VARCHAR(50), 
    tipo_de_promovente TEXT,
    tipo_de_solicitud TEXT,
    asunto TEXT,
    descripcion_del_problema TEXT,
    descripcion_de_la_atencion TEXT,
    documentacion_entregada TEXT,
    documentacion_faltante TEXT,
    estatus VARCHAR(50) check (estatus='FINALIZADO' OR estatus='EN PROCESO'),
    descripcion_estatus TEXT,
    hora_de_actualización TIME,
    fecha_de_actualizacion DATE
);



CREATE TABLE planeacion_semanal(
    id_actividad INTEGER PRIMARY KEY AUTO_INCREMENT,
    actividad VARCHAR(50),
    hora_inicio TIME,
    hora_termino TIME,
    fecha_de_actividad DATE,
    lugar_actividad VARCHAR(50),
    descripcion VARCHAR (900)
 ); 


 -- -- GENERACION DE DATOS DE PRUEBA -- --

 -- Datos de prueba registro_visitadores --
INSERT INTO registro_visitadores (numero_empleado, nombre, primer_apellido, segundo_apellido, email, password, cargo)
VALUES
(123, 'Jorge', 'Perez', 'Lopez', 'email1@email.com', '4d186321c1a7f0f354b297e8914ab240', 'VISITADOR'),
(456, 'Anahí', 'Rodriguez', 'Salas', 'email2@email.com', '2cd3d9544a602ba4f1fb2764c254f6db', 'JEFE'),
(789, 'Bertha', 'Lopez', 'Martinez', 'email3@email.com', '6e6e2ddb6346ce143d19d79b3358c16a', 'VISITADOR');

-- Datos de prueba registro_usuarios -- 
INSERT INTO registro_usuarios (nombre, primer_apellido, segundo_apellido, edad, telefono, genero, email, password)
VALUES
('Roberto', 'Hernandez', 'Fernandez', 56, 2213533213, 'MASCULINO', 'prueba1@email.com', '122b738600a0f74f7c331c0ef59bc34c'),
('Alejandra', 'Avelar', 'Soto', 32, 8874678930, 'FEMENINO', 'prueba2@email.com', '2fb6c8d2f3842a5ceaa9bf320e649ff0'),
('Fernando', 'Majin', 'Delgadillo', 25, 5543923844, 'OTRO', 'prueba3@email.com', '5a54c609c08a0ab3f7f8eef1365bfda6');

-- Datos de prueba captura_tramites -- 
INSERT INTO captura_tramites (hora_de_captura, fecha_de_captura, lugar_atencion, nombre, primer_apellido, segundo_apellido, edad, genero, identificacion, folio_de_identificacion, telefono, direccion, municipio, estado, tipo_de_promovente, tipo_de_solicitud, asunto, descripcion_del_problema, descripcion_de_la_atencion, estatus)
VALUES
('12:00 p.m.', '12-07-2022', 'Tulancingo de bravo', 'Martin', 'Merida', 'Martinez', 43, 'MASCULINO', 'INE', '322121ZA', 8923949321, 'Calle 21 de marzo 22, CP 32123', 'Tulancingo', 'Hidalgo', 'Sucesor', 'Verbal', '1301. Sucesion de derechos', 'Descripcion de prueba del tramite uno', 'Descripcion de prueba del tramite uno', 'EN PROCESO'),
('09:30 a.m.', '26-06-2022', 'Tulancingo de bravo', 'Alfredo', 'Hernandez', 'Ramirez', 33, 'OTRO', 'PASAPORTE', '4653218', 3321564895, 'Priv. Los angeles S/N, CP 46521', 'Cuautepec', 'Hidalgo', 'Sucesor', 'Verbal', '1301. Sucesion de derechos', 'Descripcion de prueba del tramite dos', 'Descripcion de prueba del tramite dos', 'FINALIZADO'),
('14:20 p.m.', '08-04-2022', 'Tulancingo de bravo', 'Regina', 'Yañez', 'Yañez', 23, 'FEMENINO', 'OTRO', 'KJFDD552', 5587423620, 'Calle vicentenario esq. Portillo 99, CP 54498', 'Agua Blanca', 'Hidalgo', 'Posesionario', 'Verbal', '1302. Posesion de una parcela', 'Descripcion de prueba del tramite tres', 'Descripcion de prueba del tramite tres', 'EN PROCESO');

-- Datos de prueba planeacion_semanal --
INSERT INTO planeacion_semanal (hora_inicio, hora_termino, fecha_de_actividad, lugar_actividad, descripcion)
VALUES
('09:00 a.m.', '15:00 p.m.', '29-07-2022', 'Singuilucan, Hgo', 'Descripcion de prueba de la actividad uno'),
('13:00 p.m.', '17:00 p.m.', '16-04-2022', 'Huehuetla, Hgo', 'Descripcion de prueba de la actividad dos'),
('09:00 a.m.', '13:00 p.m.', '14-02-2022', 'Acaxochitlan, Hgo', 'Descripcion de prueba de la actividad tres');


 -- -- CONSULTAS Y VISTAS A UTILIZAR EN LA BASE DE DATOS -- --

 -- INSERTAR USUARIO NUEVO A LA TABLA 'REGISTRO_USUARIOS' -- 
 INSERT INTO registro_usuarios(nombre,primer_apellido,segundo_apellido,edad,telefono,genero,email,password) 
 VALUES ('$nombrephp','$primerApellidophp','$segundoApellidophp','$edadphp','$telefonophp','$generophp','$emailphp','$passwordphp');

 -- INSETAR VISITADOR A LA TABLA 'REGISTRO_VISITADORES' --
 INSERT INTO registro_visitadores(numero_empleado,nombre,primer_apellido,segundo_apellido,email,password,cargo) 
 VALUES ('$numeroEmpleadophp','$nombrephp','$primerApellidophp','$segundoApellidophp', '$emailphp','$passwordphp','$cargophp');

 -- INSERTAR LA CAPTURA DE INFORMACION PARA UN TRAMITE A LA TABLA 'CAPTURA_TRAMITES' --
 INSERT INTO captura_tramites(hora_de_captura,fecha_de_captura,lugar_atencion,nombre,primer_apellido,segundo_apellido,edad,genero,identificacion,folio_de_identifiacion,telefono,direccion,municipio,estado,tipo_de_promovente,tipo_de_solicitud,asunto,descripcion_del_problema,descripcion_de_la_atencion,estatus) 
 VALUES ('$hora_capturaphp','$fecha_capturaphp','$lugar_atencionphp','$nombre_usuariophp','$primer_apellidophp','$segundo_apellidophp','$edadphp','$generophp','$identificacionphp','$telefonophp','$direccionphp','$municipiophp','$estadophp','$promoventephp','$tipo_solicitudphp','$asuntophp','$descripcion_problemaphp','$descripcion_atencionphp','$estatusphp');

 -- INSERTAR LA CAPTURA DE PLANEACION SEMANAL A LA TABLA 'PLANEACION_SEMANAL' --
 INSERT INTO planeacion_semanal (hora_inicio,hora_termino,fecha_de_actividad,lugar_actividad,descripcion)
 VALUES ('$hora_iniciophp','hora_terminophp','fechaphp','lugarphp','descripcionphp');

 -- SELECT PARA EL INICIO DE SESION BUSCANDO EN LAS TABLAS 'REGISTRO_VISITADORES' Y 'REGISTRO_USUARIOS' --
 SELECT * FROM registro_usuarios INNER JOIN registro_visitadores WHERE registro_usuarios.email = :login AND registro_usuarios.password = :passw;
 SELECT * FROM registro_usuarios INNER JOIN registro_visitadores WHERE registro_visitadores.email = :login AND registro_visitadores.password = :passw;

 -- VISTA PARA VISUALIZAR LA INFORMACION DE LOS VISITADORES --
 CREATE VIEW visitadores_view_informacion AS
 SELECT
    registro_visitadores.numero_empleado,
    registro_visitadores.nombre,
    registro_visitadores.primer_apellido,
    registro_visitadores.segundo_apellido,
    registro_visitadores.cargo,
    registro_visitadores.email
 FROM
    registro_visitadores;

 -- VISTA PARA VISUALIZAR LA INFORMACION DE LOS USUARIOS --
 CREATE VIEW usuarios_view_informacion AS
 SELECT
    registro_usuarios.id_usuario,    
    registro_usuarios.nombre,
    registro_usuarios.primer_apellido,
    registro_usuarios.segundo_apellido,
    registro_usuarios.edad,
    registro_usuarios.genero,
    registro_usuarios.email
 FROM
    registro_usuarios;

 -- VISTA PARA VISUALIZAR EL ESTADO DEL TRAMITE --
 CREATE VIEW tramites_view_estatus AS
 SELECT
    captura_tramites.id_tramite,
    captura_tramites.nombre,
    captura_tramites.primer_apellido,
    captura_tramites.segundo_apellido,
    captura_tramites.asunto,
    captura_tramites.estatus
 FROM
    captura_tramites;

